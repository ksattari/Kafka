package org.kafka.email_service.service;


import lombok.extern.slf4j.Slf4j;
import org.kafka.model.Order;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class KafkaOrderConsumer {

    @KafkaListener( topics="case-study", groupId="Group2")
    public void consumeData(Order order){

        log.info(String.format("Received message -> %s", order));

    }
}
