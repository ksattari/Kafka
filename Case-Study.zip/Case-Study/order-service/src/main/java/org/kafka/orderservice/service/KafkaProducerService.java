package org.kafka.orderservice.service;

import lombok.extern.slf4j.Slf4j;
import org.kafka.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class KafkaProducerService {

    @Autowired
    KafkaTemplate<String,Order> kafkaTemplate;

    @Value("${topic.name}")
    String topicName;

    private int iD;

    public Order send(Order order){
        log.info("Inside send method of KafkaProducerService");
        order.setOrderId(++iD);
        kafkaTemplate.send(topicName,order);
        log.info("Order was sent to Kafka  -> " + order);

        return order;
    }

}
