package org.kafka.orderservice.controller;


import lombok.extern.slf4j.Slf4j;
import org.kafka.model.Order;
import org.kafka.orderservice.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
@Slf4j
public class OrderController {

    @Autowired
    KafkaProducerService kafkaProducerService;

    @PostMapping("order")
    public Order postOrder(@RequestBody Order order){

        return kafkaProducerService.send(order);

    }
}
